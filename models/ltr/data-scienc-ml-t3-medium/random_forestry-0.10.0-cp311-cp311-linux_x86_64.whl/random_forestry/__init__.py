from .forestry import RandomForest

# Version of Rforestry
__version__ = "0.10.0"
